package com.example.portfolio_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
